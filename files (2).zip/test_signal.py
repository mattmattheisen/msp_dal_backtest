"""
Signal engine tests, with emphasis on temporal integrity.

NOTE: these import from `msp_signal`, never `signal`. The previous version of this
file did `from signal import ...`, which silently resolved to Python's stdlib
signal module -- the same collision that broke the original Render deploy.
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).parent))

from msp_signal import compute_momentum, compute_signal, lag_correlation_table


def make_df(n=48, start="2019-01"):
    dates = pd.date_range(start, periods=n, freq="MS")
    rng = np.random.default_rng(42)
    pax = np.linspace(2_500_000, 3_500_000, n) + rng.normal(0, 50_000, n)
    dal = np.linspace(40.0, 60.0, n) + rng.normal(0, 2.0, n)
    wti = np.linspace(50.0, 80.0, n) + rng.normal(0, 3.0, n)
    return pd.DataFrame({
        "year_month": dates, "passengers": pax, "close": dal,
        "wti": wti, "in_covid": False,
    })


def test_momentum_basic():
    df = make_df()
    mom = compute_momentum(df["passengers"], lookback=1)
    assert len(mom) == len(df)
    assert pd.isna(mom.iloc[0])
    assert not pd.isna(mom.iloc[1])


def test_position_is_binary():
    out = compute_signal(make_df(), momentum_mode="MoM")
    assert set(out["position"].unique()) <= {0, 1}


def test_publication_lag_shifts_signal():
    """pax_signal at t must equal pax_momentum at t - (pub_lag + signal_lag)."""
    df = make_df()
    for pub, sig in [(0, 0), (1, 0), (1, 2), (3, 1)]:
        out = compute_signal(df, publication_lag=pub, signal_lag=sig,
                             momentum_mode="MoM", oil_gate=False)
        merged = df.merge(out[["year_month", "pax_signal"]], on="year_month")
        raw = compute_momentum(df["passengers"], 1)
        expected = raw.shift(pub + sig)
        exp = df.assign(exp=expected).merge(
            merged[["year_month", "pax_signal"]], on="year_month")
        both = exp.dropna(subset=["exp", "pax_signal"])
        assert np.allclose(both["exp"], both["pax_signal"]), f"pub={pub} sig={sig}"


def test_negative_signal_lag_rejected():
    """A negative lag is not tradeable and must not silently run."""
    with pytest.raises(ValueError, match="negative"):
        compute_signal(make_df(), signal_lag=-1)


def test_gapped_index_rejected():
    """
    THE REGRESSION TEST FOR THE COVID SEAM BUG.

    Filtering rows before computing momentum made pct_change compare across the
    gap -- Jan 2022 vs Dec 2019 labelled as a one-month change. The engine must
    refuse a gapped frame rather than produce plausible-looking wrong numbers.
    """
    df = make_df(n=60, start="2018-01")
    gapped = df[~df["year_month"].dt.year.isin([2020, 2021])].reset_index(drop=True)
    with pytest.raises(ValueError, match="gap-free"):
        compute_signal(gapped)


def test_covid_rows_dropped_after_lagging():
    """
    Momentum at the first post-COVID month must reference the immediately prior
    calendar month (which was dropped), not the last pre-COVID month.
    """
    df = make_df(n=72, start="2018-01")
    df["in_covid"] = df["year_month"].dt.year.isin([2020, 2021])
    out = compute_signal(df, momentum_mode="MoM", publication_lag=0,
                         signal_lag=0, oil_gate=False)

    assert not out["year_month"].dt.year.isin([2020, 2021]).any()

    raw = compute_momentum(df["passengers"], 1)
    truth = df.assign(m=raw)
    jan22_truth = truth.loc[truth["year_month"] == "2022-01", "m"].iloc[0]
    jan22_out = out.loc[out["year_month"] == "2022-01", "pax_momentum"].iloc[0]
    assert np.isclose(jan22_truth, jan22_out)

    # And it must NOT equal the buggy across-the-gap value.
    gap_value = (df.loc[df["year_month"] == "2022-01", "passengers"].iloc[0] /
                 df.loc[df["year_month"] == "2019-12", "passengers"].iloc[0]) - 1
    assert not np.isclose(jan22_out, gap_value)


def test_oil_gate_suppresses_long():
    """With an impossibly strict gate, no long may ever fire."""
    df = make_df()
    out = compute_signal(df, momentum_mode="MoM", pax_threshold=-99.0,
                         oil_gate=True, oil_threshold=-99.0)
    assert out["position"].sum() == 0

    ungated = compute_signal(df, momentum_mode="MoM", pax_threshold=-99.0,
                             oil_gate=False)
    assert ungated["position"].sum() > 0


def test_nan_oil_signal_blocks_trade():
    """Unknown gate value must be treated as gate-fails, not gate-passes."""
    df = make_df()
    out = compute_signal(df, momentum_mode="YoY", pax_threshold=-99.0,
                         oil_gate=True, oil_threshold=99.0)
    assert not out["oil_ok"].isna().any()


def test_lag_table_uses_returns_not_levels():
    """Correlating against price levels is spurious regression; must use returns."""
    out = compute_signal(make_df(n=60), momentum_mode="MoM")
    tbl = lag_correlation_table(out)
    assert "p_bonferroni" in tbl.columns, "multiple-testing correction missing"
    assert (tbl["p_bonferroni"] >= tbl["p_value"]).all()
    assert set(tbl.loc[tbl["lag"] < 0, "tradeable"]) <= {False}
