# msp_signal.py
"""
Signal engine.  SPEC REFERENCE: BACKTEST_SPECIFICATION.md section 4, section 5

Signal generation ONLY. This module never touches prices for P&L, never opens or
closes a position, never computes a performance metric. It emits a `position`
column and nothing else. That separation is what lets the temporal logic be
audited in one place.

Named msp_signal.py rather than signal.py to avoid shadowing Python's stdlib
`signal` module (this broke the original Render deploy).

THE CENTRAL TEMPORAL CLAIM
--------------------------
    decision at close of month t  uses  pax[t - PUBLICATION_LAG - SIGNAL_LAG]

PUBLICATION_LAG is a fact about MAC's release calendar and must never be tuned.
SIGNAL_LAG is the hypothesis parameter (does pax lead DAL?) and may be tuned,
with the multiple-testing cost that implies.
"""

import numpy as np
import pandas as pd
from scipy import stats

import config


def compute_momentum(series: pd.Series, lookback: int) -> pd.Series:
    """
    Percentage change over `lookback` periods.

    PRECONDITION: `series` must be indexed on a contiguous monthly calendar with no
    gaps. pct_change is positional, not date-aware -- it counts rows, not months.
    Passing a gap-filtered series here produces silently wrong values.
    See compute_signal() for how this precondition is enforced.
    """
    return series.pct_change(periods=lookback)


def compute_signal(df: pd.DataFrame,
                   signal_lag: int = None,
                   momentum_mode: str = None,
                   pax_threshold: float = None,
                   oil_gate: bool = None,
                   oil_threshold: float = None,
                   publication_lag: int = None,
                   wti_lag: int = None,
                   seasonal_adjust: bool = None) -> pd.DataFrame:
    """
    SPEC REFERENCE: section 4 (temporal rules), section 5 (signal rules)

    Attach momentum and position columns to the aligned frame.

    ORDER OF OPERATIONS IS LOAD-BEARING
    -----------------------------------
    Momentum and all lag shifts are computed on the FULL contiguous calendar,
    BEFORE any COVID rows are dropped. The original implementation filtered COVID
    rows first and then called pct_change(), which made the first post-COVID row
    compare against Dec 2019 -- a 25-month gap labelled as a 1-month change. In
    YoY mode the same bug corrupted 12 consecutive months after the seam.

    Rows inside the COVID window are marked via `in_covid` upstream and are
    dropped at the very end, after every temporal transform has been applied on
    an unbroken monthly index.

    TEMPORAL NOTE (pax): pax[t] is not public at close of month t. MAC publishes
    monthly operations reports on a delay. Total offset applied is
    publication_lag + signal_lag.

    TEMPORAL NOTE (WTI): WTI is real-time observable. wti_lag defaults to 0. It is
    exposed as a parameter so the assumption is visible and testable, not so it
    can be optimized.

    Returns
    -------
    DataFrame with added columns:
        pax_momentum        raw momentum at month t (NOT tradeable as-of t)
        pax_signal          momentum as observable at close of month t (tradeable)
        wti_momentum        raw WTI momentum at month t
        wti_signal          WTI momentum as observable at close of month t
        pax_bull            pax_signal > threshold
        oil_ok              gate passes
        position            1 = long DAL for month t+1, 0 = cash
    """
    signal_lag      = _default(signal_lag,      config.SIGNAL_LAG)
    momentum_mode   = _default(momentum_mode,   config.MOMENTUM_MODE)
    pax_threshold   = _default(pax_threshold,   config.PAX_THRESHOLD)
    oil_gate        = _default(oil_gate,        config.OIL_GATE)
    oil_threshold   = _default(oil_threshold,   config.OIL_THRESHOLD)
    publication_lag = _default(publication_lag, config.PUBLICATION_LAG)
    wti_lag         = _default(wti_lag,         config.WTI_LAG)
    seasonal_adjust = _default(seasonal_adjust, config.SEASONAL_ADJUST)

    if momentum_mode not in ("MoM", "YoY"):
        raise ValueError(f"momentum_mode must be 'MoM' or 'YoY', got {momentum_mode!r}")
    if signal_lag < 0:
        raise ValueError(
            f"signal_lag={signal_lag} is negative. A negative lag means DAL price leads "
            "the pax signal, which is not tradeable -- it is a confirmatory diagnostic. "
            "Use lag_correlation_table() for that, not the engine."
        )
    if publication_lag < 0:
        raise ValueError("publication_lag cannot be negative.")

    df = df.copy()

    # Guard the pct_change precondition explicitly rather than trusting the caller.
    _assert_contiguous(df)

    lookback = 1 if momentum_mode == "MoM" else 12

    # -- pax leg --------------------------------------------------------------
    pax = df["passengers"]
    if seasonal_adjust and momentum_mode == "MoM":
        # NOTE: config.SEASONAL_INDEX is fitted on 2015-2019, which overlaps the
        # test period -> normalization leakage (spec UNRESOLVED-3). Disabled by
        # default. YoY differencing removes seasonality without fitting anything.
        pax = pax / df["year_month"].dt.month.map(config.SEASONAL_INDEX)

    df["pax_momentum"] = compute_momentum(pax, lookback)
    df["pax_signal"]   = df["pax_momentum"].shift(publication_lag + signal_lag)

    # -- WTI leg --------------------------------------------------------------
    df["wti_momentum"] = compute_momentum(df["wti"], lookback)
    df["wti_signal"]   = df["wti_momentum"].shift(wti_lag)

    # -- combine --------------------------------------------------------------
    df["pax_bull"] = df["pax_signal"] > pax_threshold
    if oil_gate:
        # Gate SUPPRESSES the long when oil momentum runs hot. NaN oil momentum
        # (early rows) is treated as "gate fails" -- refusing to trade on an
        # unknown gate value is the conservative reading.
        df["oil_ok"] = df["wti_signal"] < oil_threshold
        df["oil_ok"] = df["oil_ok"].where(df["wti_signal"].notna(), False)
    else:
        df["oil_ok"] = True

    df["position"] = (df["pax_bull"] & df["oil_ok"]).astype(int)

    # Rows without a valid signal are not tradeable. Mark rather than silently drop,
    # so the audit can report how many months were unusable.
    df["signal_valid"] = df["pax_signal"].notna()
    df.loc[~df["signal_valid"], "position"] = 0

    # -- COVID drop LAST, after all temporal transforms -----------------------
    if "in_covid" in df.columns and df["in_covid"].any():
        df = df[~df["in_covid"]].reset_index(drop=True)

    df = df[df["signal_valid"]].reset_index(drop=True)
    return df


def _default(value, fallback):
    return fallback if value is None else value


def _assert_contiguous(df: pd.DataFrame) -> None:
    """
    Fail loudly if the monthly index has gaps.

    pct_change() and shift() count ROWS. On a gapped frame they silently produce
    values that look plausible and are wrong. This is the single highest-severity
    failure mode in this codebase and it is worth an explicit assertion.
    """
    ym = df["year_month"]
    expected = pd.date_range(ym.min(), ym.max(), freq="MS")
    if len(expected) != len(ym) or not (ym.values == expected.values).all():
        raise ValueError(
            "compute_signal() requires a gap-free monthly index.\n"
            f"  expected {len(expected)} consecutive months, got {len(ym)} rows.\n"
            "Do NOT filter COVID (or any period) before calling this function -- "
            "lags must be applied on the unbroken calendar first."
        )


# -- Diagnostics (NOT parameter selection) --------------------------------------

def lag_correlation_table(df: pd.DataFrame,
                          min_lag: int = -3,
                          max_lag: int = 6) -> pd.DataFrame:
    """
    EXPLORATORY DIAGNOSTIC ONLY. SPEC REFERENCE: section 9.

    Correlation between pax momentum and forward DAL RETURNS at each lag.

    WHY RETURNS, NOT PRICE LEVELS: the original implementation correlated pax
    against DAL price *levels*. Two trending series correlate strongly regardless
    of any predictive relationship -- that is spurious regression, and its
    p-values are not interpretable. Correlating against returns tests the thing
    the strategy actually needs to be true.

    THIS FUNCTION MUST NOT FEED THE ENGINE. Picking the best-correlating lag on
    the full sample and then backtesting it is data snooping: the "best" lag is
    chosen using data from after every trade it would have informed.
    """
    out = []
    dal_fwd_ret = df["close"].pct_change().shift(-1)   # return over month t+1

    for lag in range(min_lag, max_lag + 1):
        pax_lagged = df["pax_momentum"].shift(lag)
        pair = pd.concat([pax_lagged, dal_fwd_ret], axis=1).dropna()
        if len(pair) < 10:
            continue
        r, p = stats.pearsonr(pair.iloc[:, 0], pair.iloc[:, 1])
        out.append({
            "lag": lag,
            "r": round(r, 4),
            "p_value": round(p, 4),
            "n_obs": len(pair),
            "tradeable": lag >= 0,
        })

    tbl = pd.DataFrame(out)
    if not tbl.empty:
        # Bonferroni over the lags scanned -- these are multiple comparisons.
        n_tests = len(tbl)
        tbl["p_bonferroni"] = (tbl["p_value"] * n_tests).clip(upper=1.0).round(4)
        tbl["sig_05"] = tbl["p_bonferroni"] < 0.05
    return tbl


def summarize_lag_table(tbl: pd.DataFrame) -> str:
    """Human-readable verdict on the lag scan, with the snooping caveat attached."""
    if tbl.empty:
        return "Lag table empty -- insufficient overlapping observations."
    sig = tbl[tbl["sig_05"]]
    best = tbl.loc[tbl["r"].abs().idxmax()]
    lines = [
        f"  Strongest |r|: lag {int(best['lag']):+d}  r={best['r']:+.3f}  "
        f"p={best['p_value']:.4f}  p_bonf={best['p_bonferroni']:.4f}  n={int(best['n_obs'])}",
    ]
    if sig.empty:
        lines.append("  NO lag survives Bonferroni correction at alpha=0.05.")
        lines.append("  The lag scan provides no evidence of a pax -> DAL return relationship.")
    else:
        lines.append(f"  {len(sig)} lag(s) survive Bonferroni correction.")
    lines.append("  DIAGNOSTIC ONLY -- do not select the engine's lag from this table.")
    return "\n".join(lines)
