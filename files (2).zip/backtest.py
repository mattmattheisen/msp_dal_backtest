# backtest.py
"""
Execution engine.  SPEC REFERENCE: BACKTEST_SPECIFICATION.md section 4.4, 6, 7

Order handling ONLY. This module consumes a `position` column produced by the
signal engine and never recomputes, adjusts, or second-guesses it. It does not
know what MSP or WTI are. Given positions and prices it produces fills, costs,
an equity curve, and a trade log.

This file previously contained a byte-identical copy of data_loader.py, so
`run_backtest`, `Trade`, and `BacktestResult` did not exist anywhere in the repo
and `metrics.py` could not import. This is the real implementation.
"""

from dataclasses import dataclass, field
from typing import List, Optional

import numpy as np
import pandas as pd

import config


@dataclass
class Trade:
    """One completed round trip: entry to exit, costs included."""
    entry_month: str
    exit_month: str
    entry_price: float
    exit_price: float
    months_held: int
    gross_pnl: float
    commission: float
    net_pnl: float
    return_pct: float
    exit_reason: str


@dataclass
class BacktestResult:
    equity_curve: pd.Series
    bh_equity_curve: pd.Series
    drawdown_pct: pd.Series
    positions: pd.Series
    months: pd.Series
    trades: List[Trade] = field(default_factory=list)
    open_trade: Optional[dict] = None
    audit: dict = field(default_factory=dict)


def run_backtest(df: pd.DataFrame,
                 initial_capital: float = None,
                 commission_pct: float = None) -> BacktestResult:
    """
    SPEC REFERENCE: section 4.4 (execution), section 6 (sizing), section 7 (costs)

    Execute the position series against DAL monthly closes.

    TEMPORAL CONTRACT
    -----------------
    `position[t]` is the decision made at the CLOSE of month t, using only
    information the signal engine has already lagged into observability. The
    return credited for that decision is month t+1's return:

        ret[t+1] = (close[t+1] - close[t]) / close[t]

    The final row carries a position that has no following month to realize, so
    it is reported as an open position rather than silently closed at the last
    price (which would fabricate a favourable exit).

    ASSUMPTION (spec UNRESOLVED-2): fills at the monthly close, no slippage and
    no bid/ask modeled. Commission only. DAL is liquid enough that a monthly
    close fill is defensible, but this is an unmodeled cost, not a zero cost.

    ASSUMPTION: position is a STATE. Consecutive long months are one continuous
    holding. Commission is charged on transitions only -- entering and exiting --
    not re-charged every month the position is simply maintained. Charging
    monthly would badly overstate costs for a low-turnover monthly strategy.

    Args:
        df: output of msp_signal.compute_signal, requires columns
            [year_month, close, position]
    """
    initial_capital = config.INITIAL_CAPITAL if initial_capital is None else initial_capital
    commission_pct  = config.COMMISSION_PCT if commission_pct is None else commission_pct

    required = {"year_month", "close", "position"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"run_backtest requires columns {sorted(missing)}")

    if len(df) < 2:
        raise ValueError(f"Need at least 2 months to realize a return, got {len(df)}.")

    months = df["year_month"].dt.strftime("%Y-%m").reset_index(drop=True)
    close = df["close"].reset_index(drop=True).astype(float)
    position = df["position"].reset_index(drop=True).astype(int)

    if (close <= 0).any():
        raise ValueError("Non-positive close price found; cannot compute returns.")

    n = len(df)
    equity = [1.0]
    bh = [1.0]
    trades: List[Trade] = []

    in_position = False
    entry_price = 0.0
    entry_month = ""
    entry_idx = 0
    n_transitions = 0

    # Decision at t, return realized over t -> t+1. Loop stops at n-1 because the
    # last row has no forward month.
    for t in range(n - 1):
        ret = (close[t + 1] - close[t]) / close[t]
        bh.append(bh[-1] * (1 + ret))

        want_long = bool(position[t])
        eq = equity[-1]

        if want_long and not in_position:
            # ENTRY at close of month t
            in_position = True
            entry_price = close[t]
            entry_month = months[t]
            entry_idx = t
            n_transitions += 1
            eq *= (1 - commission_pct)          # entry cost
            eq *= (1 + ret)

        elif want_long and in_position:
            # HOLD -- no cost
            eq *= (1 + ret)

        elif not want_long and in_position:
            # EXIT at close of month t. No market return earned this month.
            in_position = False
            n_transitions += 1
            eq *= (1 - commission_pct)          # exit cost
            trades.append(_close_trade(
                entry_month, months[t], entry_price, close[t],
                t - entry_idx, commission_pct, initial_capital, "signal_off"
            ))

        # else: flat and staying flat -- equity unchanged

        equity.append(eq)

    open_trade = None
    if in_position:
        # Do NOT mark to market as a completed trade. Report it as open.
        open_trade = {
            "entry_month": entry_month,
            "entry_price": round(entry_price, 4),
            "last_month": months[n - 1],
            "last_price": round(float(close[n - 1]), 4),
            "unrealized_pct": round((close[n - 1] - entry_price) / entry_price * 100, 2),
            "months_held": (n - 1) - entry_idx,
        }

    eq_s = pd.Series(equity, name="equity")
    bh_s = pd.Series(bh, name="bh_equity")
    running_peak = eq_s.cummax()
    dd_s = ((eq_s - running_peak) / running_peak * 100).rename("drawdown_pct")

    audit = {
        "months_total": n,
        "months_returns_realized": n - 1,
        "months_in_market": int(position[: n - 1].sum()),
        "transitions": n_transitions,
        "completed_trades": len(trades),
        "open_position": open_trade is not None,
        "commission_bps": commission_pct * 1e4,
        "fill_assumption": "monthly close, no slippage modeled",
        "first_month": months.iloc[0],
        "last_month": months.iloc[-1],
    }

    return BacktestResult(
        equity_curve=eq_s,
        bh_equity_curve=bh_s,
        drawdown_pct=dd_s,
        positions=position,
        months=months,
        trades=trades,
        open_trade=open_trade,
        audit=audit,
    )


def _close_trade(entry_month, exit_month, entry_price, exit_price,
                 months_held, commission_pct, capital, reason) -> Trade:
    """Build a Trade record with costs on both legs, sized on nominal capital."""
    gross_ret = (exit_price - entry_price) / entry_price
    gross_pnl = capital * gross_ret
    # Round-trip commission: charged on entry notional and exit notional.
    commission = capital * commission_pct + capital * (1 + gross_ret) * commission_pct
    net_pnl = gross_pnl - commission
    return Trade(
        entry_month=entry_month,
        exit_month=exit_month,
        entry_price=round(float(entry_price), 4),
        exit_price=round(float(exit_price), 4),
        months_held=int(months_held),
        gross_pnl=round(float(gross_pnl), 2),
        commission=round(float(commission), 2),
        net_pnl=round(float(net_pnl), 2),
        return_pct=round(float(gross_ret * 100), 2),
        exit_reason=reason,
    )


def trades_to_dataframe(trades: List[Trade]) -> pd.DataFrame:
    """Trade log as a DataFrame. SPEC REFERENCE: section 10, output 1."""
    if not trades:
        return pd.DataFrame(columns=[
            "entry_month", "exit_month", "entry_price", "exit_price", "months_held",
            "gross_pnl", "commission", "net_pnl", "return_pct", "exit_reason",
        ])
    return pd.DataFrame([t.__dict__ for t in trades])


# -- Look-ahead self-test ----------------------------------------------------------

def lookahead_selftest(df: pd.DataFrame) -> dict:
    """
    SPEC REFERENCE: section 11 (audit hook)

    Empirical check that the engine cannot see the future.

    Method: shuffle FUTURE returns only, leaving positions untouched. If the
    engine were peeking at future prices when forming or executing positions,
    scrambling the future would change the position series or produce a
    systematically different result. A clean engine's positions are invariant.

    This is a necessary-not-sufficient test: it catches engine-level leakage,
    not leakage baked into the signal upstream.
    """
    rng = np.random.default_rng(42)
    base = run_backtest(df)

    shuffled = df.copy().reset_index(drop=True)
    prices = shuffled["close"].values.copy()
    # Preserve the first price, permute the rest -> different future, same past.
    tail = prices[1:].copy()
    rng.shuffle(tail)
    shuffled.loc[1:, "close"] = tail

    perturbed = run_backtest(shuffled)

    positions_identical = base.positions.equals(perturbed.positions)
    return {
        "positions_invariant_to_future": positions_identical,
        "verdict": "passed" if positions_identical else "FAILED",
        "note": ("Positions unchanged when future prices are scrambled -- engine "
                 "does not condition on future prices."
                 if positions_identical else
                 "Positions CHANGED when future prices were scrambled -- LOOK-AHEAD BIAS."),
    }
