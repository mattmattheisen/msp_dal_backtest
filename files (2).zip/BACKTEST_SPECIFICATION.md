# BACKTEST SPECIFICATION — MSP Enplanement Momentum / DAL

**Status:** Derived (not original). Reconstructed from `streamlit_app.py::run_engine()`,
`msp_signal.py`, `config.py`, and README as of the current repo state.

**Purpose of this document:** The original project had no written specification. Rules
lived only inside implementation code, which meant there was no way to tell whether the
code implemented the hypothesis or the hypothesis had drifted to match the code. This
document freezes the rules. The engine implements this file and nothing else.

**Items marked `[UNRESOLVED]` are decisions the code must not make silently.** Each has a
documented default in `ASSUMPTIONS.md`; each default is conservative and each needs a human
ruling before results are reportable.

---

## 1. Hypothesis

Delta holds ~70% passenger share at MSP, its second-largest hub. Sustained increases in MSP
enplanements reflect real demand growth that leads or accompanies DAL price appreciation.
Rising fuel costs offset that demand signal, so a crude-oil gate should improve it.

**Falsifiable form:** After accounting for publication lag, transaction costs, and
out-of-sample validation, a long-only DAL strategy conditioned on MSP enplanement momentum
produces risk-adjusted returns exceeding buy-and-hold DAL.

**Null hypothesis (the thing to beat):** MSP enplanement momentum carries no information
about forward DAL returns that is not already in the price, and any observed edge is
parameter selection over ~100 monthly observations.

---

## 2. Universe

Single instrument: DAL common stock. No cross-sectional selection, therefore **no
survivorship bias exposure** — DAL is a single continuously listed name chosen ex ante for
a structural reason (MSP hub share), not screened out of a universe on performance.

Signal inputs: MSP total monthly enplanements; WTI crude spot.

---

## 3. Data Sources

| Series | Source | Frequency | Point-in-time? |
|---|---|---|---|
| DAL price | Tiingo `/tiingo/daily/DAL/prices`, `adjClose` | Monthly resample | Yes — split/div adjusted |
| MSP enplanements | MAC monthly operations reports (manual download) | Monthly | **No — see §4** |
| WTI crude | FRED `DCOILWTICO` | Daily → monthly | Yes |

`adjClose` is used deliberately: DAL pays a dividend, and unadjusted close would understate
both strategy and benchmark returns while distorting them differently depending on exposure.

---

## 4. Temporal Rules (non-negotiable)

### 4.1 Publication lag on enplanements — the binding constraint

MSP enplanement data for month *t* is **not public at the end of month *t***. MAC publishes
monthly operations reports on a delay. Any backtest that uses `pax[t]` to make a decision at
the close of month *t* is trading on information that did not exist.

Therefore:

```
pax_observable_at(t) = pax[t - PUBLICATION_LAG]
```

`PUBLICATION_LAG` is a **data property, not a tunable parameter.** It must never be optimized.
It is set once from MAC's actual release calendar and frozen.

`[UNRESOLVED-1]` Exact MAC release lag. Default: 1 month (assume month *t* data is readable
by the end of month *t+1*). Must be verified against actual report timestamps before results
are reportable.

### 4.2 Signal lag

`SIGNAL_LAG` is the separate, genuinely tunable hypothesis parameter: how many additional
months the enplanement signal is presumed to lead DAL price. Total information offset is
`PUBLICATION_LAG + SIGNAL_LAG`. These two are tracked separately and never collapsed into
one number, because one is a fact and the other is a hypothesis.

### 4.3 WTI gate timing

WTI is observable in real time. WTI momentum through the close of month *t* is legitimately
known at the close of month *t*, so it takes no publication lag. `WTI_LAG` defaults to 0 and
is exposed only so the assumption is auditable rather than buried.

### 4.4 Execution

- Decision made at the close of month *t*, using only data satisfying §4.1–4.3.
- Position held through month *t+1*.
- Return realized: `(close[t+1] - close[t]) / close[t]`.
- Entry fill at close of month *t*. Justified because the signal is fully known days-to-weeks
  before that close (publication lag guarantees it), so the close is a reachable fill, not a
  same-bar peek.

`[UNRESOLVED-2]` Fill assumption. Default: monthly close, no slippage beyond commission. DAL
is liquid enough that close-fill is defensible for monthly rebalancing, but slippage is not
modeled and must be stated in every reported result.

---

## 5. Signal Rules

### 5.1 Enplanement momentum

```
momentum[t] = (pax[t] - pax[t - LOOKBACK]) / pax[t - LOOKBACK]
```

`MOMENTUM_MODE` ∈ {MoM, YoY} sets `LOOKBACK` to 1 or 12.

**YoY is the preferred default.** MoM momentum on a strongly seasonal series measures the
calendar, not demand: MSP June is always above MSP May. YoY differences out the seasonality
structurally.

### 5.2 Seasonal adjustment (MoM only)

If `MOMENTUM_MODE == MoM` and `SEASONAL_ADJUST == True`, divide raw pax by a monthly seasonal
index before computing momentum.

`[UNRESOLVED-3]` The seasonal index currently hardcoded in `config.SEASONAL_INDEX` is
described as derived from 2015–2019 — the in-sample period. A full-sample-fitted normalizer
is future leakage. Default: seasonal adjustment **disabled**, YoY used instead. If seasonal
adjustment is wanted, the index must be recomputed on an expanding window.

### 5.3 Entry / exit

- **Long** DAL when `momentum_observable > PAX_THRESHOLD` AND gate passes.
- **Cash** otherwise. No short leg (`ALLOW_SHORT = False`).
- Position is a state, not an event: consecutive long months are one continuous holding, not
  repeated round trips. Commission charged on transitions only.

### 5.4 WTI gate

When `OIL_GATE == True`, the long signal is suppressed if `wti_momentum > OIL_THRESHOLD`,
regardless of the enplanement signal. Same `MOMENTUM_MODE` as the pax leg.

**Provenance flag:** this gate was added after observing that the passenger-only
configuration underperformed. That is post-hoc specification. The gate's economic rationale
is sound, but it must be validated out-of-sample before its contribution is treated as edge
rather than as fitting.

---

## 6. Position Sizing

Fixed 100% notional, long or flat. No leverage, no scaling, no volatility targeting.
`INITIAL_CAPITAL` is nominal — all reported figures are in equity multiples (×) rebased to
1.0, so capital scale does not affect any metric.

---

## 7. Costs

`COMMISSION_PCT = 0.001` (10 bps) charged on each transition — once entering, once exiting.
Not charged on months where position is unchanged.

`[UNRESOLVED-2 cont.]` Slippage and bid/ask are **not** modeled. At monthly frequency with
few transitions this is a second-order effect, but it is an unmodeled cost, not a zero cost.

---

## 8. Regime Filtering

`EXCLUDE_COVID` drops 2020-01 through 2021-12 as a structural break.

**This is a reportable choice, not a neutral cleaning step.** Excluding COVID removes the
single largest test of the thesis: the period when enplanements and DAL price moved together
most violently. Every reported result must state COVID handling. Results must be produced
both ways.

`[UNRESOLVED-4]` Whether COVID exclusion is defensible or is regime-shopping. Default:
report both, treat the excluded version as the primary and the included version as a
mandatory robustness check.

---

## 9. Validation Requirements

No result is reportable without:

1. **Out-of-sample split.** Parameters chosen on train only. Test untouched until final.
   Default split: train 2015–2021, test 2022 onward.
2. **Parameter sensitivity.** Performance across the neighboring parameter grid, not just at
   the optimum. A real edge degrades gracefully; a fitted one falls off a cliff.
3. **Multiple-testing accounting.** The dashboard exposes 1,120+ configurations. The number
   of configurations examined must be recorded and the significance threshold adjusted.
4. **Trade count disclosure.** Every Sharpe and win rate reported alongside its `n`.

`best_lag()` — selecting the lag with the highest full-sample correlation and then
backtesting that lag — is **prohibited as a parameter selection method.** It is permitted
only as an exploratory diagnostic, clearly labeled, never feeding the engine.

---

## 10. Required Outputs

1. Trade log (CSV): entry/exit month, prices, gross P&L, commission, net P&L, return %, exit reason
2. Equity curve, drawdown series, benchmark B&H curve
3. Metrics: CAGR, Sharpe, Sortino, Calmar, max DD, win rate, profit factor, exposure %, alpha vs B&H
4. Audit summary printed on every run (see §11)
5. `ASSUMPTIONS.md` regenerated with every material change

---

## 11. Audit Hook

Every run prints:

```
=== BACKTEST AUDIT SUMMARY ===
Data provenance:        [VERIFIED / PLACEHOLDER]
Publication lag:        N month(s) [VERIFIED / ASSUMED]
Signal lag:             N month(s)
Total info offset:      N month(s)
Look-ahead check:       [passed / FAILED]
Fill assumption:        close, no slippage
Commission:             N bps per transition
COVID period:           [excluded / included]
Sample:                 N months, N trades
Out-of-sample:          [held out / NOT HELD OUT]
Configs examined:       N
```

A run on placeholder data must refuse to print performance metrics as valid.
