#!/usr/bin/env python
# run_backtest.py
"""
Orchestrator.  SPEC REFERENCE: BACKTEST_SPECIFICATION.md section 10, 11

Calls data_loader -> msp_signal -> backtest -> metrics in sequence and prints the
mandatory audit summary. Contains no signal logic and no execution logic itself.

Usage:
    python run_backtest.py
    python run_backtest.py --mode MoM --signal-lag 1 --pax-threshold 0.05
    python run_backtest.py --include-covid --no-oil-gate
    python run_backtest.py --oos                 # train/test split report
    python run_backtest.py --allow-placeholder   # run on synthetic data, clearly marked
"""

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

import pandas as pd

import config
from data_loader import load_aligned_data, check_provenance, PlaceholderDataError
from msp_signal import compute_signal, lag_correlation_table, summarize_lag_table
from backtest import run_backtest, trades_to_dataframe, lookahead_selftest
from metrics import compute_all, print_metrics


def parse_args():
    p = argparse.ArgumentParser(description="MSP Enplanement Signal - DAL Backtest")
    p.add_argument("--mode", choices=["MoM", "YoY"], default=None)
    p.add_argument("--signal-lag", type=int, default=None)
    p.add_argument("--publication-lag", type=int, default=None,
                   help="DATA PROPERTY, not a tunable. Change only to match MAC's calendar.")
    p.add_argument("--pax-threshold", type=float, default=None)
    p.add_argument("--oil-threshold", type=float, default=None)
    p.add_argument("--no-oil-gate", action="store_true")
    p.add_argument("--include-covid", action="store_true")
    p.add_argument("--oos", action="store_true", help="Report train/test split separately")
    p.add_argument("--allow-placeholder", action="store_true",
                   help="Permit the synthetic series. Results will be marked INVALID.")
    p.add_argument("--no-charts", action="store_true")
    return p.parse_args()


def apply_overrides(args):
    if args.mode:                 config.MOMENTUM_MODE   = args.mode
    if args.signal_lag is not None:      config.SIGNAL_LAG      = args.signal_lag
    if args.publication_lag is not None: config.PUBLICATION_LAG = args.publication_lag
    if args.pax_threshold is not None:   config.PAX_THRESHOLD   = args.pax_threshold
    if args.oil_threshold is not None:   config.OIL_THRESHOLD   = args.oil_threshold
    if args.no_oil_gate:          config.OIL_GATE       = False
    if args.include_covid:        config.EXCLUDE_COVID  = False
    if args.no_charts:            config.SHOW_CHARTS    = False
    if args.allow_placeholder:    config.REQUIRE_REAL_DATA = False


def print_audit(result, data_is_real, lookahead, n_months, oos_used):
    total_offset = config.PUBLICATION_LAG + config.SIGNAL_LAG
    a = result.audit
    print("\n" + "=" * 52)
    print("  BACKTEST AUDIT SUMMARY")
    print("=" * 52)
    print(f"  Data provenance:      {'VERIFIED' if data_is_real else '*** PLACEHOLDER - RESULTS INVALID ***'}")
    print(f"  Publication lag:      {config.PUBLICATION_LAG} month(s) [ASSUMED - verify vs MAC]")
    print(f"  Signal lag:           {config.SIGNAL_LAG} month(s)")
    print(f"  Total info offset:    {total_offset} month(s)")
    print(f"  WTI lag:              {config.WTI_LAG} month(s) (real-time observable)")
    print(f"  Momentum mode:        {config.MOMENTUM_MODE}")
    print(f"  Look-ahead check:     {lookahead['verdict']}")
    print(f"  Fill assumption:      {a['fill_assumption']}")
    print(f"  Commission:           {a['commission_bps']:.1f} bps per transition")
    print(f"  COVID period:         {'excluded' if config.EXCLUDE_COVID else 'included'}")
    print(f"  Sample:               {a['months_total']} months, {a['completed_trades']} trades")
    print(f"  Months in market:     {a['months_in_market']} / {a['months_returns_realized']}")
    print(f"  Open position:        {'YES - not marked to market' if a['open_position'] else 'no'}")
    print(f"  Out-of-sample:        {'held out' if oos_used else 'NOT HELD OUT'}")
    print(f"  Configs examined:     {config.CONFIGS_EXAMINED}")
    print("=" * 52)
    if not data_is_real:
        print("  *** RESULTS ARE INVALID - SYNTHETIC DATA ***")
        print("=" * 52)


def run_one(df, label):
    df_sig = compute_signal(df)
    if len(df_sig) < 2:
        print(f"  {label}: insufficient data after lags ({len(df_sig)} rows)")
        return None, None
    result = run_backtest(df_sig)
    return df_sig, result


def main():
    args = parse_args()
    apply_overrides(args)

    print("\n" + "-" * 52)
    print("  MSP Enplanement + WTI Gate - DAL Backtest")
    print("-" * 52)

    prov = check_provenance()
    data_is_real = prov["all_real"]
    try:
        df = load_aligned_data()
    except PlaceholderDataError as e:
        if not args.allow_placeholder:
            print("\n*** REFUSING TO RUN ***\n")
            print(e)
            print("\nTo run anyway on synthetic data (results will be marked INVALID):")
            print("    python run_backtest.py --allow-placeholder\n")
            print("To use real data, set USE_LIVE_DATA=True in config.py and provide:")
            print("    TIINGO_API_KEY   https://www.tiingo.com            (free)")
            print("    FRED_API_KEY     https://fredaccount.stlouisfed.org/apikeys (free)")
            print("  MSP pax has NO API - download MAC monthly reports manually:")
            print("    https://metroairports.org/msp-passenger-and-operations-reports\n")
            return 1
        df = load_aligned_data(require_real=False)

    df_sig, result = run_one(df, "full sample")
    if result is None:
        return 1

    # Diagnostic lag scan -- explicitly NOT used to select parameters
    print("\nLag correlation diagnostic (pax momentum vs FORWARD DAL returns):")
    lt = lag_correlation_table(df_sig)
    if not lt.empty:
        print(lt.to_string(index=False))
    print(summarize_lag_table(lt))

    lookahead = lookahead_selftest(df_sig)
    m = compute_all(result)
    print_metrics(m)

    tdf = trades_to_dataframe(result.trades)
    if not tdf.empty:
        print(f"\nTrade log ({len(tdf)} completed):")
        print(tdf[["entry_month", "exit_month", "entry_price", "exit_price",
                   "months_held", "return_pct", "net_pnl"]].to_string(index=False))
        Path(config.REPORT_DIR).mkdir(exist_ok=True)
        tdf.to_csv(Path(config.REPORT_DIR) / "trade_log.csv", index=False)
        print(f"\n  trade log -> {config.REPORT_DIR}/trade_log.csv")
    else:
        print("\nNo completed trades in the selected period.")

    if result.open_trade:
        ot = result.open_trade
        print(f"\nOPEN position at end of sample: entered {ot['entry_month']} "
              f"@ {ot['entry_price']}, last {ot['last_price']} "
              f"({ot['unrealized_pct']:+.2f}% unrealized, {ot['months_held']}mo)")
        print("  Not counted as a completed trade -- marking it to market would")
        print("  fabricate an exit the strategy never took.")

    oos_used = False
    if args.oos:
        oos_used = True
        print("\n" + "=" * 52)
        print("  OUT-OF-SAMPLE SPLIT")
        print("=" * 52)
        split = pd.to_datetime(config.OOS_SPLIT_DATE, format="%Y-%m")
        for label, sub in [("TRAIN (pre-split)", df[df["year_month"] < split]),
                           ("TEST  (post-split)", df[df["year_month"] >= split])]:
            if len(sub) < 15:
                print(f"\n{label}: too few months ({len(sub)}) to evaluate")
                continue
            _, r = run_one(sub.reset_index(drop=True), label)
            if r is None:
                continue
            mm = compute_all(r)
            print(f"\n{label}  [{r.audit['first_month']} to {r.audit['last_month']}]")
            print(f"  Final equity   {mm['Final equity (x)']:>8}x   "
                  f"B&H {mm['Final B&H equity (x)']:>8}x")
            print(f"  Sharpe         {mm['Sharpe ratio']:>8}     "
                  f"trades {mm['Total trades']:>4}   win {mm['Win rate %']}%")
        print("\n  Parameters must be chosen on TRAIN only. If they were tuned")
        print("  while looking at TEST, this split proves nothing.")

    print_audit(result, data_is_real, lookahead, len(df_sig), oos_used)
    return 0


if __name__ == "__main__":
    sys.exit(main())
