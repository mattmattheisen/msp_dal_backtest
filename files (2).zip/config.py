# config.py
# All backtest parameters in one place. SPEC REFERENCE: BACKTEST_SPECIFICATION.md

import os
from dotenv import load_dotenv

load_dotenv()

# -- API keys -----------------------------------------------------------------
# Tiingo  (DAL prices)  free tier: https://www.tiingo.com
# FRED    (WTI crude)   free key:  https://fredaccount.stlouisfed.org/apikeys
# UW      (DAL options) paid:      https://unusualwhales.com/pricing?product=api
TIINGO_API_KEY         = os.getenv("TIINGO_API_KEY", "")
FRED_API_KEY           = os.getenv("FRED_API_KEY", "")
UNUSUAL_WHALES_API_KEY = os.getenv("UNUSUAL_WHALES_API_KEY", "")

USE_LIVE_DATA    = False   # True = fetch Tiingo + FRED; False = use cached data/ CSVs
REQUIRE_REAL_DATA = True   # True = refuse to run on the synthetic placeholder series

DAL_TICKER     = "DAL"
WTI_SERIES_ID  = "DCOILWTICO"     # FRED: WTI spot, Cushing OK, daily
START_DATE     = "2015-01-01"
END_DATE       = "2024-12-31"

# -- Temporal (spec section 4) -------------------------------------------------
# PUBLICATION_LAG is a DATA PROPERTY, not a tunable. MSP pax for month t is not
# public at the close of month t -- MAC publishes on a delay. Never optimize this.
# [UNRESOLVED-1] Verify against MAC's actual release timestamps.
PUBLICATION_LAG = 1        # months until MSP pax for month t is readable

# SIGNAL_LAG is the hypothesis parameter: additional months pax is presumed to lead.
SIGNAL_LAG      = 0        # total offset = PUBLICATION_LAG + SIGNAL_LAG

# WTI is real-time observable -> no publication lag. Exposed for auditability only.
WTI_LAG         = 0

# -- Signal (spec section 5) ---------------------------------------------------
# YoY is the default: MoM momentum on a strongly seasonal series measures the
# calendar, not demand. MSP June always exceeds MSP May.
MOMENTUM_MODE   = "YoY"    # "MoM" | "YoY"
PAX_THRESHOLD   = 0.05     # min pax momentum to go long (0.05 = 5%)
OIL_GATE        = True     # suppress long when WTI momentum runs hot
OIL_THRESHOLD   = 0.10     # WTI momentum above this blocks the long
SEASONAL_ADJUST = False    # [UNRESOLVED-3] index is full-sample fitted -> leakage

# Legacy 2015-2019-fitted seasonal index. Retained for reference; disabled above.
SEASONAL_INDEX = {
    1: 0.85, 2: 0.82, 3: 1.00, 4: 1.03, 5: 1.07, 6: 1.15,
    7: 1.18, 8: 1.15, 9: 1.02, 10: 1.01, 11: 0.90, 12: 0.92,
}

# -- Regime (spec section 8) ---------------------------------------------------
EXCLUDE_COVID = True       # report BOTH ways; this is a choice, not a cleaning step
COVID_START   = "2020-01"
COVID_END     = "2021-12"

# -- Execution (spec sections 6, 7) --------------------------------------------
INITIAL_CAPITAL = 100_000
COMMISSION_PCT  = 0.001    # 10 bps per transition (entry and exit each)
ALLOW_SHORT     = False

# -- Validation (spec section 9) -----------------------------------------------
OOS_SPLIT_DATE  = "2022-01"   # train before, test on/after. Do not peek.
CONFIGS_EXAMINED = 1          # increment honestly when scanning parameters

# -- Output --------------------------------------------------------------------
REPORT_DIR  = "reports"
SHOW_CHARTS = True
SAVE_CHARTS = True
VERBOSE     = True
