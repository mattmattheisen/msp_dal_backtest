"""Execution engine tests."""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).parent))

import config
from backtest import run_backtest, trades_to_dataframe, lookahead_selftest


def make_signal_df(positions, prices):
    n = len(positions)
    return pd.DataFrame({
        "year_month": pd.date_range("2020-01", periods=n, freq="MS"),
        "close": [float(p) for p in prices],
        "position": positions,
    })


def test_always_long_tracks_bh_minus_costs():
    prices = [10, 11, 12, 13, 14]
    r = run_backtest(make_signal_df([1] * 5, prices), commission_pct=0.0)
    assert np.isclose(r.equity_curve.iloc[-1], r.bh_equity_curve.iloc[-1])


def test_always_cash_is_flat():
    r = run_backtest(make_signal_df([0] * 5, [10, 20, 5, 30, 15]))
    assert np.allclose(r.equity_curve.values, 1.0)
    assert r.audit["completed_trades"] == 0


def test_commission_charged_on_transitions_only():
    """Ten held months must cost the same as one round trip, not ten."""
    prices = list(range(10, 22))
    held = run_backtest(make_signal_df([1] * 10 + [0, 0], prices), commission_pct=0.01)
    assert held.audit["transitions"] == 2
    assert len(held.trades) == 1


def test_open_position_not_counted_as_trade():
    """Ending long must not fabricate an exit."""
    r = run_backtest(make_signal_df([0, 1, 1, 1, 1], [10, 11, 12, 13, 99]))
    assert r.open_trade is not None
    assert r.audit["completed_trades"] == 0
    assert r.open_trade["entry_month"] == "2020-02"


def test_drawdown_non_positive():
    r = run_backtest(make_signal_df([1, 1, 0, 1, 1], [10, 8, 12, 9, 11]))
    assert (r.drawdown_pct <= 1e-9).all()


def test_trade_return_sign_matches_prices():
    r = run_backtest(make_signal_df([1, 1, 0, 0], [10, 12, 12, 12]))
    assert len(r.trades) == 1
    assert r.trades[0].return_pct > 0
    r2 = run_backtest(make_signal_df([1, 1, 0, 0], [10, 8, 8, 8]))
    assert r2.trades[0].return_pct < 0


def test_net_pnl_below_gross_after_costs():
    r = run_backtest(make_signal_df([1, 1, 0, 0], [10, 12, 12, 12]), commission_pct=0.01)
    t = r.trades[0]
    assert t.net_pnl < t.gross_pnl
    assert t.commission > 0


def test_no_lookahead():
    """Scrambling future prices must not change any position."""
    rng = np.random.default_rng(7)
    n = 40
    df = pd.DataFrame({
        "year_month": pd.date_range("2020-01", periods=n, freq="MS"),
        "close": 50 + np.cumsum(rng.normal(0, 2, n)),
        "position": rng.integers(0, 2, n),
    })
    assert lookahead_selftest(df)["verdict"] == "passed"


def test_rejects_too_short_sample():
    with pytest.raises(ValueError, match="at least 2"):
        run_backtest(make_signal_df([1], [10]))


def test_rejects_nonpositive_price():
    with pytest.raises(ValueError, match="Non-positive"):
        run_backtest(make_signal_df([1, 1, 0], [10, 0, 5]))


def test_trade_log_schema():
    r = run_backtest(make_signal_df([1, 1, 0, 0], [10, 12, 12, 12]))
    cols = set(trades_to_dataframe(r.trades).columns)
    assert {"entry_month", "exit_month", "net_pnl", "commission", "exit_reason"} <= cols
