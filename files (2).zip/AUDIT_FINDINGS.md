# Audit Findings — MSP/DAL Pairs Backtest

Audit of the repository as cloned from `github.com/mattmattheisen/msp_dal_backtest`.
Severity: **S1** blocks any use of results, **S2** materially changes results, **S3** hygiene.

---

## S1-1 — Reported results were computed on synthetic data

`streamlit_app.py` does not call `data_loader.py`. It carries its own hardcoded
`MSP_DATA`, `DAL_DATA`, and `WTI_DATA` dicts, and the app footer states it directly:
*"MSP pax: MAC annual reports, estimated monthly distributions. DAL: approximate monthly
closes. Production build requires verified data feeds."*

The committed CSVs in `data/` are byte-identical to those dicts. The MSP series has a
near-constant year-over-year increment — real enplanement data does not behave that way.

**Consequence:** the README's reference table (+9.7% / Sharpe 0.18 pax-only, +26% /
Sharpe 0.42 gated) does not describe the MSP–DAL relationship. It describes an
arithmetic property of a generated series.

**Fix applied:** `data_loader.check_provenance()` fingerprints the placeholder series;
`run_backtest.py` refuses to run without `--allow-placeholder` and stamps
`*** RESULTS INVALID ***` on the audit block when placeholder data is in use.

---

## S1-2 — The repo did not run at all

- `backtest.py` was a byte-identical copy of `data_loader.py`. `run_backtest()`, `Trade`,
  and `BacktestResult` existed nowhere in the repository.
- `metrics.py` did `from backtest import BacktestResult, Trade` — guaranteed ImportError.
- `run_backtest.py` imported `from src.data_loader import ...`; there is no `src/`.
- `test_signal.py` did `from signal import ...`, which resolves to Python's **stdlib**
  `signal` module — the same collision the README says broke the Render deploy, still
  live in the test suite.

Confirmed: `python run_backtest.py` → `ModuleNotFoundError: No module named 'src'`.

**Fix applied:** real execution engine written in `backtest.py`; all imports corrected to
the flat layout; tests rewritten against `msp_signal`.

---

## S1-3 — COVID rows were filtered *before* momentum was computed

The highest-severity logic bug. `build_df(exclude_covid)` drops 2020–2021 rows, and
`compute_changes()` then calls `pct_change()` on the filtered frame. `pct_change` counts
**rows**, not months.

Measured on the shipped data:

| Month | Labelled as | Actually compares | Reported |
|---|---|---|---|
| 2022-01 | 1-month change | 2022-01 vs **2019-12** (25-month gap) | pax −32.3%, WTI **+39.0%** |

That +39.0% WTI figure exceeds every oil-gate threshold offered in the dashboard
(5/10/15/20/30%), so **the gate fires at the seam for a reason that is purely a data
artifact.** In YoY mode the corruption is worse: `pct_change(12)` reaches back to
2019-01 instead of 2021-01, corrupting twelve consecutive months after the seam.

After the fix, 2022-01 reads pax −12.5% / WTI +13.6% — computed against the true prior
calendar month.

**Fix applied:** all momentum and lag transforms run on the unbroken monthly calendar;
COVID rows are flagged upstream and dropped last. `_assert_contiguous()` raises if a
gapped frame is ever passed in. Regression test: `test_covid_rows_dropped_after_lagging`.

---

## S1-4 — No publication lag on enplanement data

The engine used `pax[t]` to make a decision at the close of month *t*. MAC publishes MSP
monthly operations reports as documents on a delay — the data for month *t* is not public
at the close of month *t*. **Every backtested trade used information that did not exist
at the moment it was placed.**

**Fix applied:** `PUBLICATION_LAG` is separated from `SIGNAL_LAG` and applied first.
Publication lag is a data property and must never be tuned; signal lag is the hypothesis
parameter. Both are reported separately in the audit block. Current value (1 month) is an
assumption flagged `[UNRESOLVED-1]` — **it needs verification against MAC's actual release
timestamps, and if the true lag is 2 months every result to date is optimistic.**

---

## S2-1 — `best_lag()` was data snooping

`best_lag()` scanned lags −3 to +6 and returned the highest absolute correlation, for use
as the engine's lag. That selects a parameter using the full sample, including data from
after every trade the parameter informs.

Two further problems in the same function:
- It correlated pax against DAL **price levels**. Two trending series correlate strongly
  regardless of any predictive relationship — spurious regression, p-values uninterpretable.
- Ten lags scanned, no multiple-testing correction.

**Fix applied:** the lag table now correlates against **forward DAL returns**, carries
Bonferroni-corrected p-values, flags which lags are tradeable (lag ≥ 0), and is labelled
diagnostic-only. `best_lag()` is removed from the engine path entirely.

---

## S2-2 — The oil gate is post-hoc, and the grid is large enough to guarantee a winner

Per the README the gate was added *after* the passenger-only result came in weak. That is
post-hoc specification: the rationale is economically sound, but structurally it is a
parameter added because it improved performance.

Sweeping the full dashboard grid (672 valid configurations of mode × lag × threshold ×
gate × oil threshold × COVID handling):

```
Sharpe   median +0.436   max +1.261   min −0.498
Sharpe > 0 in 90% of configurations
Beat buy-and-hold in 50% of configurations
Median trades per configuration: 7
```

The best configuration reaches Sharpe 1.26 — but 90% of configurations are positive, so a
positive result is the base rate here, not evidence. Decomposing the gate's contribution:

```
Gate OFF                                    median Sharpe +0.257
Gate ON, median oil threshold (honest)      median Sharpe +0.530
Gate ON, best oil threshold (cherry-picked) median Sharpe +0.593
```

*(Computed on placeholder data — these figures illustrate the method and the size of the
selection effect, not a real finding about DAL.)*

**Fix applied:** `CONFIGS_EXAMINED` in config, surfaced in the audit block; `--oos` flag
adds a train/test split; spec §9 prohibits reporting any result without one.

---

## S2-3 — Seasonal index fitted on the evaluation period

`config.SEASONAL_INDEX` is documented as derived from 2015–2019, which overlaps the
backtest window — a full-sample-fitted normalizer, i.e. future leakage.

**Fix applied:** disabled by default; `MOMENTUM_MODE` now defaults to **YoY**, which
removes seasonality structurally rather than by fitting. MoM momentum on a series where
June always exceeds May measures the calendar, not demand.

---

## S2-4 — Metric bugs that flatter results

- `sortino_ratio`: with no losing months `downside.std()` is NaN; the guard
  `if downside.std() == 0` is False for NaN, so **NaN leaked into reported Sortino**.
- `profit_factor`: returned `inf` with no losing trades. On 3 trades that reads as a
  spectacular edge; it means "too few trades to have lost yet."
- The final open position was closed at the last available price and counted as a
  completed winning trade — fabricating an exit the strategy never took.

**Fix applied:** both metrics return NaN in degenerate cases; open positions are reported
separately as unrealized and excluded from trade statistics.

---

## S2-5 — Sample size cannot support the reported statistics

The best configuration produced **6 completed trades** at an 83.3% win rate.
95% confidence interval on that win rate: **[48%, 99%]** — it includes 50%.

The README's headline comparison (56% vs 67% win rate) is not a distinguishable
difference at this sample size. Median trades per configuration across the grid is 7.

**Fix applied:** `print_metrics()` emits an explicit caution below n=30; every reported
Sharpe and win rate now carries its trade count.

---

## S3 — Hygiene

- README documented a `src/`, `notebooks/`, `tests/` tree that does not exist (flat repo).
- `markov_regime_diagnostic.py` is described at length in the README and is **absent**.
- `requirements.txt` pinned `yfinance` and `hmmlearn`; nothing imports either.
- Quickstart says `cd msp-dal-backtest`; the repo is `msp_dal_backtest`.
- `_init_.py` is misnamed (single underscores) so it never functioned as `__init__.py`.

---

## What is NOT wrong

- **No survivorship bias.** Single ticker chosen ex ante for a structural reason.
- **The economic thesis is sound.** Delta plus its regional partners handle roughly 71% of
  MSP traffic; the hub relationship is real.
- **Commission was modeled** from the start, which is more than many retail backtests do.
- **The lag parameter existed at all** — the original author was already thinking about
  lead/lag, which is the right instinct. It was applied to the wrong quantity.

---

## Verdict

The strategy is **not yet tested**. Nothing here says the thesis is wrong — it says the
thesis has not been evaluated. What was measured was a synthetic series, through an engine
that could not run, with a seam artifact driving the gate, using data that would not have
been available at trade time.

Order of operations from here:
1. Obtain real MAC enplanement data and verify the publication lag. **Nothing else matters until this is done.**
2. Re-run with `--oos`, parameters frozen on train.
3. Only then apply the statistical validator to whatever survives.
