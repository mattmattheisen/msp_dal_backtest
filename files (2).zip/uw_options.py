# uw_options.py
"""
Unusual Whales options data for DAL.  SPEC REFERENCE: not yet in spec -- see below.

STATUS: EXPLORATORY. No UW-derived feature is part of BACKTEST_SPECIFICATION.md.
Nothing in this module may feed the engine until a hypothesis for it is written
down FIRST. Bolting options features onto a strategy that is already being tuned
multiplies the multiple-testing problem rather than adding evidence.

Base URL: https://api.unusualwhales.com
Auth:     Authorization: Bearer <token>   (all endpoints are GET)
Docs:     https://api.unusualwhales.com/docs

THE BINDING CONSTRAINT: HISTORICAL DEPTH
----------------------------------------
This backtest runs 2015-2024. UW options flow history does not go back that far,
and depth varies by endpoint and subscription tier. Before building any feature
here, run probe_history() to find the actual first available date. If UW history
starts in, say, 2022, then a UW-derived signal can only ever be tested on the
handful of years that remain -- which is a smaller sample than the one that
already cannot support the current parameter count.

A shorter sample with more features is the wrong direction. Check depth first.

THE SECOND CONSTRAINT: POINT-IN-TIME
------------------------------------
Options flow is intraday. Folding an intraday series into a monthly strategy
requires deciding what "the value at the close of month t" means, and getting it
wrong reintroduces look-ahead. Use the point-in-time flow aggregates UW documents
as stable/reproducible rather than recomputing from the live tape, which can be
revised.
"""

import os
import time
from typing import Optional

import pandas as pd
import requests

import config

BASE = "https://api.unusualwhales.com"


class UWError(RuntimeError):
    pass


def _headers() -> dict:
    if not config.UNUSUAL_WHALES_API_KEY:
        raise EnvironmentError(
            "UNUSUAL_WHALES_API_KEY not set.\n"
            "  API access is a paid add-on: https://unusualwhales.com/pricing?product=api\n"
            "  Then add to .env:  UNUSUAL_WHALES_API_KEY=your_token"
        )
    return {
        "Authorization": f"Bearer {config.UNUSUAL_WHALES_API_KEY}",
        "Accept": "application/json",
    }


def _get(path: str, params: dict = None, retries: int = 3) -> dict:
    """GET with backoff. UW rate-limits; do not hammer it in a backtest loop."""
    url = f"{BASE}{path}"
    for attempt in range(retries):
        resp = requests.get(url, headers=_headers(), params=params or {}, timeout=30)
        if resp.status_code == 429:
            wait = 2 ** attempt
            print(f"  rate limited, retrying in {wait}s")
            time.sleep(wait)
            continue
        if resp.status_code == 401:
            raise UWError("401 Unauthorized -- check UNUSUAL_WHALES_API_KEY and tier.")
        if resp.status_code == 403:
            raise UWError(f"403 Forbidden -- {path} is not in your subscription tier.")
        resp.raise_for_status()
        return resp.json()
    raise UWError(f"Rate limited after {retries} attempts: {path}")


# -- Verified endpoints (from https://api.unusualwhales.com/docs) -------------------
# Only endpoints confirmed present in the published docs are wrapped here. UW's own
# AI guidance warns that models routinely hallucinate plausible-looking paths such as
# /api/options/flow -- the real flow-alerts path is /api/option-trades/flow-alerts.

def greek_exposure(ticker: str = "DAL", **params) -> pd.DataFrame:
    """GET /api/stock/{ticker}/greek-exposure -- daily GEX/DEX/vanna history."""
    data = _get(f"/api/stock/{ticker}/greek-exposure", params)
    return pd.DataFrame(data.get("data", data))


def iv_rank(ticker: str = "DAL", **params) -> pd.DataFrame:
    """GET /api/stock/{ticker}/iv-rank -- IV rank/percentile history."""
    data = _get(f"/api/stock/{ticker}/iv-rank", params)
    return pd.DataFrame(data.get("data", data))


def volatility_stats(ticker: str = "DAL", **params) -> pd.DataFrame:
    """GET /api/stock/{ticker}/volatility/stats"""
    data = _get(f"/api/stock/{ticker}/volatility/stats", params)
    return pd.DataFrame(data.get("data", data))


def realized_volatility(ticker: str = "DAL", **params) -> pd.DataFrame:
    """
    GET /api/stock/{ticker}/volatility/realized

    NOTE: realized vol is BACKWARD-looking (computed from returns). Implied vol is
    FORWARD-looking (from the options market). These are different quantities and
    must never be substituted for one another.
    """
    data = _get(f"/api/stock/{ticker}/volatility/realized", params)
    return pd.DataFrame(data.get("data", data))


def options_volume(ticker: str = "DAL", **params) -> pd.DataFrame:
    """GET /api/stock/{ticker}/options-volume -- daily call/put volume + premium."""
    data = _get(f"/api/stock/{ticker}/options-volume", params)
    return pd.DataFrame(data.get("data", data))


def oi_change(ticker: str = "DAL", **params) -> pd.DataFrame:
    """GET /api/stock/{ticker}/oi-change -- open interest changes."""
    data = _get(f"/api/stock/{ticker}/oi-change", params)
    return pd.DataFrame(data.get("data", data))


def flow_alerts(ticker: str = "DAL", **params) -> pd.DataFrame:
    """
    GET /api/option-trades/flow-alerts -- unusual flow alerts.

    NOT /api/options/flow. That path does not exist; it is a common hallucination.
    """
    data = _get("/api/option-trades/flow-alerts", {"ticker": ticker, **params})
    return pd.DataFrame(data.get("data", data))


def darkpool(ticker: str = "DAL", **params) -> pd.DataFrame:
    """GET /api/darkpool/{ticker} -- dark pool prints."""
    data = _get(f"/api/darkpool/{ticker}", params)
    return pd.DataFrame(data.get("data", data))


def ohlc(ticker: str = "DAL", candle_size: str = "1d", **params) -> pd.DataFrame:
    """
    GET /api/stock/{ticker}/ohlc/{candle_size}

    Could consolidate price data onto UW and retire the Tiingo dependency. Verify
    whether UW's prices are split/dividend ADJUSTED before switching -- Tiingo's
    adjClose is, and swapping to unadjusted prices would silently change every
    return in the backtest.
    """
    data = _get(f"/api/stock/{ticker}/ohlc/{candle_size}", params)
    return pd.DataFrame(data.get("data", data))


# -- Diagnostics ------------------------------------------------------------------

def probe_history(ticker: str = "DAL") -> pd.DataFrame:
    """
    RUN THIS FIRST.

    Determine how far back each endpoint actually returns data on your tier. Until
    this is known, no UW-derived feature can be scoped -- and a feature that only
    covers the last 2-3 years cannot be validated against a 10-year backtest.
    """
    probes = {
        "greek_exposure":  greek_exposure,
        "iv_rank":         iv_rank,
        "options_volume":  options_volume,
        "oi_change":       oi_change,
        "volatility_stats": volatility_stats,
    }
    rows = []
    for name, fn in probes.items():
        try:
            df = fn(ticker)
            date_col = next(
                (c for c in df.columns if "date" in c.lower() or "time" in c.lower()),
                None,
            )
            if date_col is None or df.empty:
                rows.append({"endpoint": name, "status": "ok", "rows": len(df),
                             "earliest": "no date column", "latest": ""})
            else:
                d = pd.to_datetime(df[date_col], errors="coerce").dropna()
                rows.append({"endpoint": name, "status": "ok", "rows": len(df),
                             "earliest": str(d.min().date()) if len(d) else "-",
                             "latest": str(d.max().date()) if len(d) else "-"})
        except Exception as e:
            rows.append({"endpoint": name, "status": f"{type(e).__name__}",
                         "rows": 0, "earliest": str(e)[:60], "latest": ""})
    return pd.DataFrame(rows)


def to_monthly(df: pd.DataFrame, date_col: str, value_cols: list,
               how: str = "last") -> pd.DataFrame:
    """
    Collapse a daily/intraday UW series to month-end observations.

    TEMPORAL NOTE: `how="last"` takes the final observation IN the month, which is
    knowable at the close of that month and therefore usable for a decision made at
    that close. Do NOT use "mean" of a partially-elapsed month, and never use any
    aggregation that reaches into month t+1.
    """
    out = df.copy()
    out[date_col] = pd.to_datetime(out[date_col])
    out = out.set_index(date_col).sort_index()
    agg = out[value_cols].resample("ME").agg(how)
    agg = agg.reset_index()
    agg["year_month"] = agg[date_col].dt.to_period("M").dt.to_timestamp()
    return agg[["year_month"] + value_cols]


if __name__ == "__main__":
    print("Probing Unusual Whales history depth for DAL...\n")
    try:
        print(probe_history("DAL").to_string(index=False))
    except EnvironmentError as e:
        print(e)
