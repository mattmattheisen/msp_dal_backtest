# MSP/DAL Pairs Backtest

Tests whether Minneapolis-St. Paul International Airport (MSP) passenger momentum is a
tradeable leading signal for Delta Air Lines (DAL), gated by WTI crude momentum.

Built for Gambit Capital Management.

> ## STATUS: RESULTS WITHDRAWN — REBUILD IN PROGRESS
>
> An audit found that the previously reported results (+9.7% / Sharpe 0.18 passenger-only,
> +26% / Sharpe 0.42 with the WTI gate) were computed on **synthetic placeholder data**
> through an engine that **could not execute**, with a **look-ahead bias** in the signal
> and a **data artifact** driving the oil gate.
>
> Those numbers do not describe the MSP–DAL relationship and should not be cited.
> See [`AUDIT_FINDINGS.md`](AUDIT_FINDINGS.md).
>
> The engine is now rebuilt and correct. It is waiting on real MSP enplanement data.

## Thesis

Delta and its regional partners handle roughly 70% of MSP passenger traffic, its
second-largest hub. Sustained increases in MSP enplanements should reflect real demand
growth that precedes or accompanies DAL price appreciation. This project tests whether
that relationship is tradeable, and whether filtering for rising fuel costs improves it.

**Not yet answered.** See status above.

## Documents

| File | Purpose |
|---|---|
| `BACKTEST_SPECIFICATION.md` | The rules. The engine implements this and nothing else. |
| `AUDIT_FINDINGS.md` | What was wrong, severity-ranked, with measurements. |
| `ASSUMPTIONS.md` | Every assumption not explicit in the original project. |

## Repository structure

```
msp_dal_backtest/            # flat layout, no src/ package
├── data/
│   ├── msp_passengers.csv   # PLACEHOLDER — replace with MAC data
│   ├── dal_prices.csv       # PLACEHOLDER — cache; real data via Tiingo
│   └── wti_prices.csv       # cache; real data via FRED DCOILWTICO
├── data_loader.py           # ingestion only, no logic
├── msp_signal.py            # signal engine only, no execution
├── backtest.py              # execution engine only, no signals
├── metrics.py               # performance math only
├── uw_options.py            # Unusual Whales client (EXPLORATORY, not wired in)
├── visualize.py
├── streamlit_app.py         # dashboard (still on hardcoded data — see audit S1-1)
├── run_backtest.py          # orchestrator + audit hook
├── config.py
└── test_*.py                # 34 tests incl. temporal-integrity regressions
```

The four-way split (ingestion / signal / execution / analytics) is deliberate: if signal
and execution live in one function, neither can be audited independently.

## Quickstart

```bash
git clone https://github.com/mattmattheisen/msp_dal_backtest.git
cd msp_dal_backtest
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env          # add API keys
python run_backtest.py
```

`run_backtest.py` **will refuse to run** on the placeholder data. That is intentional.
To see the pipeline execute anyway (results stamped INVALID):

```bash
python run_backtest.py --allow-placeholder
```

## Data sources

| Series | Source | Access |
|---|---|---|
| DAL price | Tiingo `adjClose` | Free tier — https://www.tiingo.com |
| WTI crude | FRED `DCOILWTICO` | Free key — https://fredaccount.stlouisfed.org/apikeys |
| MSP pax | MAC monthly operations reports | **No API — manual download** |
| DAL options | Unusual Whales | Paid add-on, optional |

MSP enplanement data is the bottleneck: MAC publishes PDFs/documents, not a machine-readable
feed. The series must be assembled by hand from
https://metroairports.org/msp-passenger-and-operations-reports

## The temporal rule that matters most

MSP data for month *t* is **not public at the close of month *t***. MAC publishes on a
delay. The original engine traded on same-month enplanement figures — information that did
not exist at trade time.

```
decision at close of month t  uses  pax[t - PUBLICATION_LAG - SIGNAL_LAG]
```

`PUBLICATION_LAG` is a **fact about MAC's release calendar** and must never be tuned.
`SIGNAL_LAG` is the hypothesis parameter. They are tracked separately and never collapsed.

**`PUBLICATION_LAG` is currently set to 1 month as an assumption.** It needs verification
against actual MAC report timestamps. If the true lag is 2 months, every result is optimistic.

## Signal logic

```
momentum = (pax[t] - pax[t - lookback]) / pax[t - lookback]
```

Long DAL when lagged momentum exceeds the threshold and the oil gate passes; cash otherwise.
No short leg.

**YoY is the default**, not MoM. MoM momentum on a strongly seasonal series measures the
calendar — MSP June always exceeds MSP May. YoY differences that out structurally, without
fitting a seasonal index to the evaluation period.

**WTI gate:** suppresses the long when WTI momentum runs hot, regardless of the passenger
signal. Note that this gate was added *after* the passenger-only result came in weak — it
must survive out-of-sample validation before its contribution counts as edge.

## Validation

```bash
python run_backtest.py --oos          # train/test split
python -m pytest -q                   # 34 tests
```

No result is reportable without an out-of-sample split, a stated trade count, and an honest
`CONFIGS_EXAMINED`. The dashboard exposes 672+ valid configurations; 90% of them produce a
positive Sharpe on the placeholder data, so "it was positive" is a base rate, not evidence.

## Known deployment constraints

- `msp_signal.py` is not named `signal.py` — that shadows a stdlib module and broke Render.
- Pandas `.style`/`applymap` formatting was removed from the dashboard after deploy errors.
  Do not reintroduce without testing against the pinned pandas version.

## Not yet built

- `markov_regime_diagnostic.py` — described in earlier versions of this README but never
  committed. `hmmlearn` was removed from requirements accordingly.
- Jet fuel crack spread to replace the raw WTI gate (more precise fuel-cost signal).
- Any Unusual Whales feature. `uw_options.py` is a client, not a signal. Run
  `probe_history()` first: UW history likely does not reach 2015, which caps what can be
  tested.
