# data_loader.py
"""
Data acquisition layer.  SPEC REFERENCE: BACKTEST_SPECIFICATION.md section 3

Ingestion only. No signal logic, no execution logic, no performance math.

Three series:
    DAL price      Tiingo daily -> monthly adjClose        (requires TIINGO_API_KEY)
    WTI crude      FRED DCOILWTICO daily -> monthly close  (requires FRED_API_KEY)
    MSP pax        MAC monthly operations reports (CSV)    (manual download, no API exists)

CRITICAL: This module refuses to silently substitute placeholder data for real data.
The CSVs shipped in the original repo were synthetic estimates, and the results derived
from them were reported as if real. is_placeholder() exists to make that failure loud.
"""

import hashlib
import os
from pathlib import Path

import pandas as pd
import requests

import config

DATA_DIR = Path(__file__).parent / "data"


class PlaceholderDataError(RuntimeError):
    """Raised when synthetic/estimated data is used where real data is required."""


# -- Placeholder detection ----------------------------------------------------------

# Fingerprints of the synthetic series committed to the original repo. These are the
# smooth, evenly-incremented values from streamlit_app.py's hardcoded dicts.
_PLACEHOLDER_PAX_HEAD = [2600000.0, 2400000.0, 3000000.0, 3100000.0, 3300000.0]
_PLACEHOLDER_DAL_HEAD = [46.5, 47.2, 48.1, 46.8, 45.2]


def is_placeholder(df: pd.DataFrame, column: str, fingerprint: list) -> bool:
    """
    Detect the known synthetic series by value fingerprint.

    Returns True if the first N values match the placeholder data exactly.
    """
    if len(df) < len(fingerprint):
        return False
    head = df[column].head(len(fingerprint)).tolist()
    return all(abs(a - b) < 1e-6 for a, b in zip(head, fingerprint))


def _smoothness_warning(series: pd.Series, label: str) -> str | None:
    """
    Heuristic: real monthly airport/price data is not perfectly smooth year over year.
    If every YoY delta is near-identical, the series was almost certainly generated.
    """
    if len(series) < 24:
        return None
    yoy = series.diff(12).dropna()
    if len(yoy) < 12:
        return None
    if yoy.std() == 0:
        return f"{label}: YoY deltas have zero variance -- series is synthetic."
    cv = abs(yoy.std() / yoy.mean()) if yoy.mean() != 0 else float("inf")
    if cv < 0.05:
        return (f"{label}: YoY deltas are suspiciously uniform (CV={cv:.3f}). "
                "Verify this is real reported data, not an interpolation.")
    return None


# -- MSP passenger data -------------------------------------------------------------

def load_msp_passengers(require_real: bool = True) -> pd.DataFrame:
    """
    Load MSP monthly enplanement data from CSV.

    SPEC REFERENCE: section 3. MAC publishes monthly operations reports as documents;
    there is no machine-readable API, so this series must be assembled by hand from
    https://metroairports.org/msp-passenger-and-operations-reports

    ASSUMPTION: 'passengers' is TOTAL passengers (enplaned + deplaned) or enplanements
    consistently -- whichever it is, it must be consistent across the whole series.
    Mixing the two mid-series creates a phantom level shift that looks like a signal.

    Args:
        require_real: if True, raise PlaceholderDataError on detecting synthetic data.
    """
    path = DATA_DIR / "msp_passengers.csv"
    if not path.exists():
        raise FileNotFoundError(
            f"MSP passenger data not found at {path}\n"
            "MAC provides no API. Download the monthly operations reports from:\n"
            "  https://metroairports.org/msp-passenger-and-operations-reports\n"
            "Format: year_month,passengers  (e.g. 2015-01,3012456)"
        )

    df = pd.read_csv(path)
    df.columns = df.columns.str.strip().str.lower()

    missing = {"year_month", "passengers"} - set(df.columns)
    if missing:
        raise ValueError(f"msp_passengers.csv missing columns: {sorted(missing)}")

    df["year_month"] = pd.to_datetime(df["year_month"], format="%Y-%m")
    df = df.sort_values("year_month").reset_index(drop=True)
    df["passengers"] = df["passengers"].astype(float)

    _validate_monthly_continuity(df, "MSP passengers")

    if is_placeholder(df, "passengers", _PLACEHOLDER_PAX_HEAD):
        msg = (
            "MSP passenger data is the SYNTHETIC PLACEHOLDER series from the original repo.\n"
            "These are estimated monthly distributions, not MAC reported figures.\n"
            "Any result computed from this data is meaningless.\n"
            "Replace data/msp_passengers.csv with real MAC monthly report data."
        )
        if require_real:
            raise PlaceholderDataError(msg)
        print(f"\n*** WARNING ***\n{msg}\n")

    warn = _smoothness_warning(df["passengers"], "MSP passengers")
    if warn:
        print(f"*** DATA WARNING *** {warn}")

    return df


# -- DAL price data -----------------------------------------------------------------

def load_dal_prices(require_real: bool = True) -> pd.DataFrame:
    """Load DAL monthly close prices from Tiingo (live) or cached CSV (offline)."""
    if config.USE_LIVE_DATA:
        return _fetch_dal_tiingo()
    return _load_dal_csv(require_real=require_real)


def _load_dal_csv(require_real: bool = True) -> pd.DataFrame:
    path = DATA_DIR / "dal_prices.csv"
    if not path.exists():
        raise FileNotFoundError(
            f"DAL price data not found at {path}\n"
            "Set USE_LIVE_DATA=True and provide TIINGO_API_KEY to fetch from Tiingo."
        )
    df = pd.read_csv(path)
    df.columns = df.columns.str.strip().str.lower()
    df["year_month"] = pd.to_datetime(df["year_month"], format="%Y-%m")
    df = df.sort_values("year_month").reset_index(drop=True)
    df["close"] = df["close"].astype(float)

    _validate_monthly_continuity(df, "DAL prices")

    if is_placeholder(df, "close", _PLACEHOLDER_DAL_HEAD):
        msg = (
            "DAL price data is the SYNTHETIC PLACEHOLDER series from the original repo.\n"
            "These are approximate monthly closes, not actual adjusted closes.\n"
            "Set USE_LIVE_DATA=True with a Tiingo key to fetch real prices."
        )
        if require_real:
            raise PlaceholderDataError(msg)
        print(f"\n*** WARNING ***\n{msg}\n")

    return df


def _fetch_dal_tiingo() -> pd.DataFrame:
    """
    Fetch DAL monthly adjusted close from Tiingo.

    ASSUMPTION: adjClose is used, not close. DAL pays a dividend; unadjusted prices
    would understate returns for both strategy and benchmark, and would distort them
    asymmetrically because the strategy is not always in the market.
    """
    if not config.TIINGO_API_KEY:
        raise EnvironmentError(
            "TIINGO_API_KEY not set.\n"
            "  1. Free key: https://www.tiingo.com  (free tier covers this use)\n"
            "  2. Add to .env:  TIINGO_API_KEY=your_key_here"
        )

    url = (
        f"https://api.tiingo.com/tiingo/daily/{config.DAL_TICKER}/prices"
        f"?startDate={config.START_DATE}&endDate={config.END_DATE}"
        f"&resampleFreq=monthly&token={config.TIINGO_API_KEY}"
    )
    resp = requests.get(url, headers={"Content-Type": "application/json"}, timeout=30)
    resp.raise_for_status()
    raw = resp.json()

    if not raw:
        raise ValueError(f"Tiingo returned no data for {config.DAL_TICKER}. Check date range.")

    df = pd.DataFrame(raw)[["date", "adjClose"]]
    df.columns = ["year_month", "close"]
    df["year_month"] = pd.to_datetime(df["year_month"]).dt.to_period("M").dt.to_timestamp()
    df = df.sort_values("year_month").reset_index(drop=True)
    df["close"] = df["close"].astype(float)

    _cache_csv(df, "dal_prices.csv", "close")
    return df


# -- WTI crude data -----------------------------------------------------------------

def load_wti(require_real: bool = True) -> pd.DataFrame:
    """Load WTI monthly series from FRED (live) or cached CSV (offline)."""
    if config.USE_LIVE_DATA:
        return _fetch_wti_fred()
    return _load_wti_csv(require_real=require_real)


def _load_wti_csv(require_real: bool = True) -> pd.DataFrame:
    path = DATA_DIR / "wti_prices.csv"
    if not path.exists():
        raise FileNotFoundError(
            f"WTI data not found at {path}\n"
            "Set USE_LIVE_DATA=True with a FRED_API_KEY to fetch series DCOILWTICO,\n"
            "or download manually from https://fred.stlouisfed.org/series/DCOILWTICO"
        )
    df = pd.read_csv(path)
    df.columns = df.columns.str.strip().str.lower()
    df["year_month"] = pd.to_datetime(df["year_month"], format="%Y-%m")
    df = df.sort_values("year_month").reset_index(drop=True)
    df["wti"] = df["wti"].astype(float)
    _validate_monthly_continuity(df, "WTI")
    return df


def _fetch_wti_fred() -> pd.DataFrame:
    """
    Fetch WTI spot from FRED series DCOILWTICO (daily), resampled to month-end close.

    ASSUMPTION: month-END close, not month AVERAGE. The original streamlit app used
    monthly averages. A month average is not fully known until the month ends, and
    comparing an average to an end-of-month decision point blurs the information
    boundary. End-of-month close is unambiguously observable at the decision moment.

    TEMPORAL NOTE: WTI is a real-time observable series. No publication lag applies
    (contrast with MSP enplanements -- see spec section 4.1).
    """
    if not config.FRED_API_KEY:
        raise EnvironmentError(
            "FRED_API_KEY not set.\n"
            "  1. Free key (instant): https://fredaccount.stlouisfed.org/apikeys\n"
            "  2. Add to .env:  FRED_API_KEY=your_key_here"
        )

    url = (
        "https://api.stlouisfed.org/fred/series/observations"
        f"?series_id={config.WTI_SERIES_ID}"
        f"&observation_start={config.START_DATE}"
        f"&observation_end={config.END_DATE}"
        f"&api_key={config.FRED_API_KEY}&file_type=json"
    )
    resp = requests.get(url, timeout=30)
    resp.raise_for_status()
    obs = resp.json().get("observations", [])

    if not obs:
        raise ValueError(f"FRED returned no observations for {config.WTI_SERIES_ID}.")

    df = pd.DataFrame(obs)[["date", "value"]]
    df["date"] = pd.to_datetime(df["date"])
    # FRED encodes missing values (holidays, non-trading days) as "."
    df["value"] = pd.to_numeric(df["value"], errors="coerce")
    df = df.dropna(subset=["value"])

    monthly = (
        df.set_index("date")["value"]
        .resample("ME").last()          # month-end close, not mean
        .rename("wti")
        .reset_index()
    )
    monthly["year_month"] = monthly["date"].dt.to_period("M").dt.to_timestamp()
    monthly = monthly[["year_month", "wti"]].dropna().reset_index(drop=True)

    _cache_csv(monthly, "wti_prices.csv", "wti")
    return monthly


# -- Shared helpers -----------------------------------------------------------------

def _validate_monthly_continuity(df: pd.DataFrame, label: str) -> None:
    """
    Verify the monthly index has no gaps and no duplicates.

    A silent month gap shifts every subsequent .shift(n) by one period, which
    quietly breaks the publication-lag guarantee without raising anything.
    """
    ym = df["year_month"]
    if ym.duplicated().any():
        dupes = ym[ym.duplicated()].dt.strftime("%Y-%m").tolist()
        raise ValueError(f"{label}: duplicate months found: {dupes}")

    expected = pd.date_range(ym.min(), ym.max(), freq="MS")
    missing = set(expected) - set(ym)
    if missing:
        gaps = sorted(pd.Timestamp(m).strftime("%Y-%m") for m in missing)
        raise ValueError(
            f"{label}: {len(gaps)} missing month(s) in series: {gaps[:12]}"
            f"{' ...' if len(gaps) > 12 else ''}\n"
            "Gaps break shift-based lag alignment. Fill or truncate before use."
        )


def _cache_csv(df: pd.DataFrame, filename: str, value_col: str) -> None:
    out = DATA_DIR / filename
    DATA_DIR.mkdir(exist_ok=True)
    save = df.copy()
    save["year_month"] = save["year_month"].dt.strftime("%Y-%m")
    save[["year_month", value_col]].to_csv(out, index=False)
    if config.VERBOSE:
        print(f"  cached -> {out}")


# -- Merge + align ------------------------------------------------------------------

def check_provenance() -> dict:
    """
    Report whether each series is real or the known synthetic placeholder.

    Called by the orchestrator so the audit summary reflects actual data
    provenance rather than merely whether an exception happened to fire.
    """
    status = {}
    try:
        pax = pd.read_csv(DATA_DIR / "msp_passengers.csv")
        pax.columns = pax.columns.str.strip().str.lower()
        pax["passengers"] = pax["passengers"].astype(float)
        status["msp_pax"] = not is_placeholder(pax, "passengers", _PLACEHOLDER_PAX_HEAD)
    except Exception:
        status["msp_pax"] = False
    try:
        dal = pd.read_csv(DATA_DIR / "dal_prices.csv")
        dal.columns = dal.columns.str.strip().str.lower()
        dal["close"] = dal["close"].astype(float)
        status["dal_price"] = not is_placeholder(dal, "close", _PLACEHOLDER_DAL_HEAD)
    except Exception:
        status["dal_price"] = False
    status["all_real"] = all(status.values())
    return status


def load_aligned_data(require_real: bool = None) -> pd.DataFrame:
    """
    Load, align, and filter all three series.

    SPEC REFERENCE: section 3, section 8

    Returns DataFrame with columns:
        year_month, passengers, close, wti

    NOTE: This function does NOT apply publication lag, momentum, or any signal
    transform. That is the signal engine's job (msp_signal.py). Keeping ingestion
    free of temporal logic is what makes the lag auditable in one place.
    """
    require_real = config.REQUIRE_REAL_DATA if require_real is None else require_real

    msp = load_msp_passengers(require_real=require_real)
    dal = load_dal_prices(require_real=require_real)
    wti = load_wti(require_real=require_real)

    df = msp.merge(dal, on="year_month", how="inner").merge(wti, on="year_month", how="inner")
    df = df.sort_values("year_month").reset_index(drop=True)

    if df.empty:
        raise ValueError("No overlapping months across MSP / DAL / WTI series.")

    if config.EXCLUDE_COVID:
        # NOTE: rows are dropped, which makes the series non-contiguous in calendar
        # time. The signal engine must therefore apply lags BEFORE this filter, or
        # shift(1) will silently jump the COVID gap. See msp_signal.compute_signal.
        covid_start = pd.to_datetime(config.COVID_START, format="%Y-%m")
        covid_end = pd.to_datetime(config.COVID_END, format="%Y-%m")
        mask = (df["year_month"] >= covid_start) & (df["year_month"] <= covid_end)
        df = df.assign(in_covid=mask)
    else:
        df = df.assign(in_covid=False)

    if config.VERBOSE:
        span = f"{df['year_month'].min():%Y-%m} to {df['year_month'].max():%Y-%m}"
        print(f"  aligned: {len(df)} months ({span}), "
              f"{int(df['in_covid'].sum())} flagged COVID")

    return df


if __name__ == "__main__":
    df = load_aligned_data(require_real=False)
    print(df.head(12).to_string())
