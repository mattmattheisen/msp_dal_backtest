# ASSUMPTION LOG

Every assumption made that was not explicit in the original project. Required by
BACKTEST_SPECIFICATION.md section 10.

## Data

1. **MSP `passengers` is a consistent measure throughout.** The column may be total
   passengers (enplaned + deplaned) or enplanements only. Whichever it is, mixing the two
   mid-series creates a phantom level shift indistinguishable from a demand signal. Not yet
   verified against MAC's report definitions.
2. **DAL prices use Tiingo `adjClose`, not `close`.** DAL pays a dividend. Unadjusted prices
   understate returns for both strategy and benchmark, and distort them asymmetrically
   because the strategy is not always in the market.
3. **WTI uses FRED `DCOILWTICO` month-END close, not month average.** The original used
   monthly averages. A month's average is not fully known until the month ends, which blurs
   the information boundary at the decision point.
4. **FRED missing values** (holidays, non-trading days, encoded as `.`) are dropped before
   resampling rather than forward-filled.

## Temporal

5. **`PUBLICATION_LAG = 1 month`.** MSP enplanement data for month *t* is assumed readable by
   the end of month *t+1*. **This is a guess and it matters more than any tuned parameter.**
   MAC publishes monthly operations reports as documents with no API and no stated SLA. If
   the true lag is 2 months, every backtested result is optimistic. **Verify against actual
   report publication timestamps before reporting anything.**
6. **`WTI_LAG = 0`.** WTI is real-time observable, so no publication lag applies.
7. **Entry fills at the monthly close of the decision month.** Justified because publication
   lag guarantees the signal is known days-to-weeks before that close, so it is a reachable
   fill rather than a same-bar peek.
8. **The final open position is not marked to market.** Closing it at the last price would
   fabricate an exit the strategy never took. Reported separately as unrealized.

## Execution

9. **No slippage and no bid/ask modeled.** Commission only, 10 bps per transition. DAL is
   liquid and turnover is low, so this is second-order — but it is an unmodeled cost, not a
   zero cost.
10. **Commission charged on transitions only,** not per month held. Position is a state;
    consecutive long months are one holding.
11. **Fixed 100% notional, long or flat.** No leverage, no sizing rule, no vol targeting.

## Signal

12. **`MOMENTUM_MODE` defaults to YoY, not MoM.** MoM momentum on a strongly seasonal series
    measures the calendar rather than demand: MSP June always exceeds MSP May. This changes
    the default behaviour from the original build.
13. **Seasonal adjustment disabled by default.** `config.SEASONAL_INDEX` is described as
    fitted on 2015–2019, which overlaps the evaluation period — a full-sample-fitted
    normalizer is future leakage. YoY differencing removes seasonality without fitting.
14. **A NaN oil-gate value blocks the trade.** Refusing to trade on an unknown gate value is
    the conservative reading; the alternative silently permits longs in early rows.
15. **Negative signal lags are rejected by the engine.** A negative lag means DAL leads pax,
    which is a confirmatory diagnostic, not a tradeable signal.

## Statistical

16. **`profit_factor` returns NaN when there are no losing trades,** not `inf`. On a handful
    of trades, `inf` reads as a spectacular edge when it actually means "too few trades to
    have lost yet."
17. **`sortino_ratio` returns NaN when there is no downside,** rather than leaking NaN
    through a `== 0` comparison that is always False for NaN (the original bug).
18. **`CONFIGS_EXAMINED` must be incremented by hand** when scanning parameters. Nothing
    enforces this. It is on the operator to be honest about how many configurations were
    looked at before reporting a p-value.

## Not assumed — still open

- `[UNRESOLVED-1]` True MAC publication lag (assumption 5).
- `[UNRESOLVED-2]` Slippage magnitude (assumption 9).
- `[UNRESOLVED-3]` Whether seasonal adjustment is wanted at all, and if so on an expanding window.
- `[UNRESOLVED-4]` Whether COVID exclusion is defensible or is regime-shopping.
