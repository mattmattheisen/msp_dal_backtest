# src/backtest.py
"""
Backtest engine.

Month-end execution model:
  - Signal computed using pax data available at end of month t
  - Trade entered at DAL close on last trading day of month t+1 (after lag)
  - Position held until signal reverses
  - Cash earns 0% (conservative; could add T-bill return in future version)
  - Commission applied on each entry and exit
"""

import numpy as np
import pandas as pd
from dataclasses import dataclass, field
from typing import List
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
import config


@dataclass
class Trade:
    entry_month: str
    exit_month: str
    entry_price: float
    exit_price: float
    shares: float
    gross_pnl: float
    net_pnl: float
    return_pct: float
    commission: float


@dataclass
class BacktestResult:
    equity_curve: pd.Series          # Rebased to 1.0
    bh_equity_curve: pd.Series       # Buy-and-hold DAL rebased to 1.0
    drawdown_pct: pd.Series          # Rolling drawdown from peak (%)
    trades: List[Trade]
    positions: pd.Series             # 1 = long, 0 = cash
    labels: pd.Series                # year_month index
    metrics: dict = field(default_factory=dict)


def run_backtest(df_signal: pd.DataFrame,
                 initial_capital: float = None,
                 commission_pct: float = None) -> BacktestResult:
    """
    Execute the backtest on a signal-enriched DataFrame.

    Parameters
    ----------
    df_signal : output of signal.compute_signal() — must have [position, close]
    initial_capital : starting portfolio value (default: config.INITIAL_CAPITAL)
    commission_pct : round-trip commission rate (default: config.COMMISSION_PCT)

    Returns
    -------
    BacktestResult with equity curves, drawdown, trade log, and metrics
    """
    initial_capital = initial_capital or config.INITIAL_CAPITAL
    commission_pct  = commission_pct  if commission_pct is not None else config.COMMISSION_PCT

    df = df_signal.copy().reset_index(drop=True)
    n = len(df)

    equity   = [1.0]
    bh       = [1.0]
    drawdown = [0.0]
    trades: List[Trade] = []

    peak       = 1.0
    in_pos     = False
    entry_px   = 0.0
    entry_mon  = ""
    capital    = float(initial_capital)

    for i in range(n - 1):
        position_now = df.loc[i, "position"]
        price_now    = df.loc[i, "close"]
        price_next   = df.loc[i + 1, "close"]
        month_now    = df.loc[i, "year_month"].strftime("%Y-%m")
        month_next   = df.loc[i + 1, "year_month"].strftime("%Y-%m")

        dal_return = (price_next - price_now) / price_now
        bh_last    = bh[-1]
        bh.append(round(bh_last * (1 + dal_return), 6))

        eq_last = equity[-1]

        if position_now == 1:
            # Enter position if not already in
            if not in_pos:
                in_pos    = True
                entry_px  = price_now
                entry_mon = month_now
                # Deduct entry commission
                entry_comm = capital * commission_pct
                capital   -= entry_comm

            # Apply DAL return
            new_eq = round(eq_last * (1 + dal_return), 6)
            equity.append(new_eq)

        else:
            # Exit position if we were in one
            if in_pos:
                in_pos = False
                exit_comm   = capital * commission_pct
                capital    -= exit_comm
                gross_pnl   = (price_now - entry_px) / entry_px * initial_capital
                total_comm  = initial_capital * commission_pct * 2
                net_pnl     = gross_pnl - total_comm
                ret_pct     = (price_now - entry_px) / entry_px * 100

                trades.append(Trade(
                    entry_month  = entry_mon,
                    exit_month   = month_now,
                    entry_price  = round(entry_px, 2),
                    exit_price   = round(price_now, 2),
                    shares       = round(initial_capital / entry_px, 2),
                    gross_pnl    = round(gross_pnl, 2),
                    net_pnl      = round(net_pnl, 2),
                    return_pct   = round(ret_pct, 2),
                    commission   = round(total_comm, 2),
                ))

            equity.append(round(eq_last, 6))

        # Rolling drawdown
        current_eq = equity[-1]
        if current_eq > peak:
            peak = current_eq
        drawdown.append(round((current_eq - peak) / peak * 100, 4))

    equity_s   = pd.Series(equity,   name="equity")
    bh_s       = pd.Series(bh,       name="bh_equity")
    drawdown_s = pd.Series(drawdown, name="drawdown_pct")
    labels_s   = df["year_month"].iloc[:len(equity)]

    result = BacktestResult(
        equity_curve    = equity_s,
        bh_equity_curve = bh_s,
        drawdown_pct    = drawdown_s,
        trades          = trades,
        positions       = df["position"].iloc[:len(equity)],
        labels          = labels_s,
    )

    return result


def trades_to_dataframe(trades: List[Trade]) -> pd.DataFrame:
    if not trades:
        return pd.DataFrame()
    return pd.DataFrame([t.__dict__ for t in trades])


if __name__ == "__main__":
    from data_loader import load_aligned_data
    from signal import compute_signal

    df = load_aligned_data()
    df_sig = compute_signal(df)
    result = run_backtest(df_sig)

    tdf = trades_to_dataframe(result.trades)
    print("\nTrade log:")
    print(tdf.to_string() if not tdf.empty else "No trades.")
    print(f"\nFinal equity:   {result.equity_curve.iloc[-1]:.4f}x")
    print(f"Buy & hold:     {result.bh_equity_curve.iloc[-1]:.4f}x")
    print(f"Max drawdown:   {result.drawdown_pct.min():.2f}%")
